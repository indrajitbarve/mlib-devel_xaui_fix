#!/bin/bash

planAhead -mode batch -source "`dirname $0`/casper_create_ppr.tcl"
